import styled from "styled-components";

export const StyledTitle = styled.h1`
    margin: 1rem 0;
    color: #ff2968;
`;