import styled from "styled-components";

export const StyledTodoList = styled.ul`
    padding-left: 0;
`;